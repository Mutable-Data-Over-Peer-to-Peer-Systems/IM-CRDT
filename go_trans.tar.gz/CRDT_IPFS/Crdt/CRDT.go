package CRDT

type CRDT interface {
	ToFile(file string)
}
